Shawn Casserly
scasser1@binghamton.edu
language = C++

code was tested on bingsuns

lls doesnt work on the server side because apparently the sh shell cant find ls on bingsuns
lcd doesnt work
bye doesnt close the socket on the server side
ls,pwd,cd,lpwd,and bye do work
have to restart ftpclient every time you want to perform a command on the server side
