#!/usr/bin/ruby

#question1.rb - Answer1
#Author:Casserly, Shawn
#Date:3/26/2014

list = [ ]
sum = 0
0.upto(5){
	|n| sum = sum + n
	list[n] = sum
}
print list
print "\n"

