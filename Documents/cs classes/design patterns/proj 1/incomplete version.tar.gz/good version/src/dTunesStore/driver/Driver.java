package dTunesStore.driver;

import dTunesStore.util.Debug;
import dTunesStore.util.Results;
import dTunesStore.dataStore.FileReaderHelper;
import dTunesStore.dataStore.PopulateWorker;
import dTunesStore.dataStore.SearchWorker;
import dTunesStore.dataStore.MusicStore;
import java.util.Vector;
public class Driver {

    public static void main(String args[]) {

	FileReaderHelper frh1 = new FileReaderHelper("musicinfo.txt");
	PopulateWorker pw = new PopulateWorker(3, frh1);
	pw.startThreads();
	MusicStore ms = new MusicStore();
	ms = pw.getMusicStore();
	//FileReaderHelper frh2 = new FileReaderHelper("searchinfo.txt");
	//Results r = new Results();
	//SearchWorker sw = new SearchWorker(2, ms, frh2, r);
	//sw.startThreads();
	//r = sw.getResults();
	//r.printResults();
	System.out.println("done :)");
	
    } // end main(...)
} // end class Driver
