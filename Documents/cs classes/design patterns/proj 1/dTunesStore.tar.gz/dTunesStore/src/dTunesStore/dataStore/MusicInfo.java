
package dTunesStore.dataStore;

import dTunesStore.util.Debug;
import dTunesStore.util.Results;


public class MusicInfo {

} // end class MusicInfo

