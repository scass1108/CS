

package dTunesStore.dataStore;

import dTunesStore.util.Debug;
import dTunesStore.util.Results;


public class SearchWorker implements Runnable {

    public SearchWorker() {
	// PLACEHOLDER
    }

    public void run() {
	// PLACEHOLDER

    } // end run(...)

} // end class SearchWorker

