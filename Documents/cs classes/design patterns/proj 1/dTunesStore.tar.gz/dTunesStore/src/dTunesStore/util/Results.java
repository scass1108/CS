
package dTunesStore.util;

public class Results {


}