
package dTunesStore.driver;

import dTunesStore.util.Debug;
import dTunesStore.util.Results;
import dTunesStore.dataStore.PopulateWorker;
import dTunesStore.dataStore.SearchWorker;

public class Driver {

    public static void main(String args[]) {

	System.out.println("Hello Design-Patterns students. Welcome to Assignment 1\n");

    } // end main(...)
} // end class Driver
