
package dTunesStore.util;

public class Debug {
    private static int DEBUG_VALUE;

    // accessor and mutator for DEBUG_VALUE

}