
package dTunesStore.util;

public class Debug {
    private static int DEBUG_VALUE;

    // accessor for DEBUG_VALUE
	public static int getDebug(){
		return DEBUG_VALUE;	
	}

	// mutator for DEBUG_VALUE
	public static void setDebug(int value){
		DEBUG_VALUE = value;
	}
	

}
