package dTunesStore.dataStore;

import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.InterruptedException;
import java.io.IOException;

public class FileReaderHelper
{
	BufferedReader br;
	public FileReaderHelper(String filename)
	{
		try
		{
			br = new BufferedReader(new FileReader(filename));
		}
		catch(IOException e)
		{
			System.out.println("Bad filename");
			System.exit(1);
		}
	}
	public synchronized String read()
	{	
		String s = null;
		try
    		{	
		    	if((s = br.readLine()) != null)
		    	{
		    		return s;
		    	}

		    	br.close();
		}
		catch(IOException e)
		{
			
		}
		
		return s;
	}
}
