package dTunesStore.dataStore;

import dTunesStore.util.Debug;
import dTunesStore.util.Results;
import java.util.Vector;
import java.lang.Thread;
import java.lang.InterruptedException;

public class PopulateWorker implements Runnable 
{
	int threadsToMake;	
	MusicStore ms = new MusicStore();
	FileReaderHelper frh;
	
    public PopulateWorker(int threadsToMake, FileReaderHelper frh)
    {
    	this.threadsToMake = threadsToMake;
    	this.frh = frh;
    	this.ms = ms;
    }
    public PopulateWorker(MusicStore ms, FileReaderHelper frh)
    {
    	this.ms = ms;
    	this.frh = frh;
    }
    public void startThreads()
    { 
   	System.out.println("starting popWorker threads");
    	Thread t = null;
    	PopulateWorker pw;

    	for(int i = 0; i < threadsToMake; i++)
	{
		pw = new PopulateWorker(ms, frh);		
		t = new Thread(pw);
		t.start();
	}
	for(int i = 0; i < threadsToMake; i++)
	{
		try
		{
			t.join();
		}
		catch(InterruptedException ie)
		{
			System.out.println("things went wrong");
			System.exit(1);
		}
    	}
    	//System.out.println("music store populated");
    	//System.out.println("displaying data");
    	//ms.displayData();
    }
    public void run() 
    {    	
    	String s;
    	while((s = frh.read()) != null)
    	{
    		putInMusicStore(ms, s);
    		
    	}    	
    } 

    public synchronized void putInMusicStore(MusicStore ms, String s)
    {
    	MusicInfo mi = processString(s);
    
    	ms.addMusicInfo(mi.getSong(), mi);
    	ms.addMusicInfo(mi.getAlbum(), mi);
    	ms.addMusicInfo(mi.getSinger(), mi);
    	//System.out.println(s);
    }     
    public synchronized MusicInfo processString(String s)
    {
    	String delims = "[ ]+";
    	String[]tokens = s.split(delims);
    	MusicInfo m = new MusicInfo();
    	m.setSong(tokens[0]);
    	m.setAlbum(tokens[1]);
    	m.setSinger(tokens[2]);
    	m.setDuration(Integer.parseInt(tokens[3]));
    	return m;
    }

    public MusicStore getMusicStore()
    {
    	return ms;
    }

} // end class PopulateWorker

