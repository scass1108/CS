package dTunesStore.dataStore;

import dTunesStore.util.Debug;
import dTunesStore.util.Results;
import java.util.Vector;
import java.lang.Thread;
import java.lang.InterruptedException;
import java.util.Hashtable;

public class SearchWorker implements Runnable {

    int threadsToMake;
    MusicStore ms = new MusicStore();
    FileReaderHelper frh;
    Results r = new Results();

    public SearchWorker(int threadsToMake, MusicStore ms, FileReaderHelper frh, Results r) {
	this.threadsToMake = threadsToMake;
	this.ms = ms;
	this.frh = frh;
	this.r = r;
    }
    public SearchWorker(MusicStore ms, FileReaderHelper frh, Results r)
    {
    	this.ms = ms;
    	this.frh = frh;
    	this.r = r;
    }
    
    public void startThreads()
    {
    	System.out.println("Starting searchworker threads");
    	Thread t = null;
    	SearchWorker sw;
    	for(int i = 0; i < this.threadsToMake; i++)
    	{
    		sw = new SearchWorker(this.ms, this.frh, this.r);
    		t = new Thread(sw);
    		t.start();
    	}
    	for(int i = 0; i < this.threadsToMake; i++)
	{
		try
		{
			t.join();
		}
		catch(InterruptedException ie)
		{
			System.out.println("things went wrong");
			System.exit(1);
		}
    	}
    }
    
    public void run() {
	
	String s;
	while((s = frh.read()) != null)
	{
		searchForMatch(ms, s);
	}
    }
      
    public synchronized void searchForMatch(MusicStore ms, String s)
    {
    	MusicInfo mi = new MusicInfo();
    	System.out.println("string to search " + s);
    	if(ms.getMusicInfo(s) != null)
    	{
    		System.out.println("match found, key = " + s);
    		r.addResult(ms.getMusicInfo(s));
    	}
    }
    public Results getResults()
    {
    	return r;
    }
} 
