/**Interface for effort put into each activity
*/

package studentOrientation.util;

public interface EffortInterface{
	//getter for effort value
	public double getEffort();
	//setter for effort value
	public void setEffort(double value);


}
