package studentBackup.util;
import studentBackup.util.Visitor;
public interface Acceptor
{
	public void accept(Visitor v);
}
