package studentBackup.util;
import studentBackup.bst.BST;
public interface Visitor
{
	public void visit(BST bst);
}
	
