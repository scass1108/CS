Name: Shawn Casserly
E-Mail:  scasser1@binghamton.edu

files: mycommand.c, readme, and makefile
