shawn casserly

program only executes foreground commands, and only commands with or without ars
