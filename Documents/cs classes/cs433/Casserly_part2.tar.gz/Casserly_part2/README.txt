Shawn Casserly
Program 2
CS 433

To Run Program:

- cd into directory
- type "ant compile" to compile
- type "ant run" to run program

Status Report:

Language Used: JAVA

Bugs:
- doesnt compute similarity properly but they are almost the same as the results posted

