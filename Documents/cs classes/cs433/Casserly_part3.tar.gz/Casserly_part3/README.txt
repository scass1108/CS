Shawn Casserly
Program 3
CS 433

To Run Program:

- cd into directory
- type "ant compile" to compile
- type "ant run" to run program

Status Report:

Language Used: JAVA

Bugs:
- doesnt compute correct posting list and some errors in dictionary
- only writes posting list as docID, tf instead of docID, tf, tfw
- doesnt compute similarity properly since the posting list and dictionary arent correct
- couldnt compute map5 and map10 or do manual check on similarity since results werent properly computed

