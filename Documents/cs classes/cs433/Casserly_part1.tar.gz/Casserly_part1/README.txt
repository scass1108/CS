Shawn Casserly
Program 1
2/25/2014
CS 433

To Run Program:

- cd into directory
- type "ant compile" to compile
- type "ant run" to run program

Status Report:

Language Used: JAVA

Bugs:
- doesnt compute term frequency properly
- some empty spaces and single letters made it through the tokenizer
- some words were concatenated together due to the tokenizer


Number of Terms In Dictionary: 513
