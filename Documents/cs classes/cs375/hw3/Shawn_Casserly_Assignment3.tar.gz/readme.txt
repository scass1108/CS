for the programming part i assignmed each city a number so i could make a 2-d array that could hold the edges between them.

everything was hardcoded into my program so it can only tell you how to get from Toronto to NYC with this graph

output: Toronto to Buffalo to Rochester to Syracuse to Binghamton to Scranton to New York City

